/*
 * Scheme.java
 *
 * Created on 23 août 2008, 15:59
 */

package lotrecscheme;

/**
 *
 * @author  proprietaire
 */
public class Scheme extends SchemeWithKawa {
    
    

}
