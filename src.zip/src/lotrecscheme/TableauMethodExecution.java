/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lotrecscheme;

import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class TableauMethodExecution {

    final private Scheme scheme;
    final private ArrayList<TableauExecutionStep> steps = new ArrayList<TableauExecutionStep>();
    private ExecutionThread executionThread;
    
    String errorMessage = null;
    private ActionListener actionListener;

    private boolean isSchemeFalse(Object schemeExpression) {
        return (schemeExpression.toString().equalsIgnoreCase("false")
                || schemeExpression.toString().equalsIgnoreCase("#f"));
    }

    private boolean isSchemeTrue(String schemeExpression) {
        return (schemeExpression.equalsIgnoreCase("true")
                || schemeExpression.equalsIgnoreCase("#t"));
    }

    private boolean schemeIsUnSAT() {
        return isSchemeTrue(scheme.eval("(isunsat?)"));
    }

    private boolean schemeIsSAT() {
        return isSchemeTrue(scheme.eval("(issat?)"));
    }

    private Object schemeContinue() {
        return scheme.eval("(continue! rules)");
    }

    public boolean isUnSAT(int i) {
        if ((i == getLastStep()) & (errorMessage != null)) {
            return errorMessage.contains("unsatisfiable");
        } else {
            return false;
        }
    }

    public boolean isSAT(int i) {
        return steps.get(i).getNextRule().equals("sat");
    }
    
    public boolean isError(int i)
    {
        return steps.get(i).getNextRule() == null;
    }

    private void schemeExtractError() {
        String err = scheme.popError();

        if (err != null) {
            errorMessage = err;
        }


    }

    public void start() {
        executionThread = new ExecutionThread();
        executionThread.start();

        if (actionListener != null) {
            actionListener.actionPerformed(null);
        }
    }

    public void stop() {
        if(executionThread.isAlive())
            executionThread.interrupt();
    }

    private class ExecutionThread extends Thread {

        @Override
        public void run() {
            remplir();
        }
    }

    TableauMethodExecution(Scheme scheme, String graphInitial) {
        this.scheme = scheme;
        scheme.eval("(element-generator-initialize)");
        scheme.eval("(start! rules '" + graphInitial + ")");

        addPreModelAndNextRule();



    }

    public void remplir() {
        //(errorMessage == null) &
        while (!schemeIsUnSAT() & !schemeIsSAT()) {
            schemeContinue();
            schemeExtractError();
            
            if(errorMessage != null) {
                break;
            }
            addPreModelAndNextRule();
            if (actionListener != null) {
                actionListener.actionPerformed(null);
            }
        }



        scheme.eval("(couplerulesigma-getrule couplerulesigma)");
        scheme.eval("(graph-make (machinestate-set-get state))");
    }

    public int getNumberSteps() {
        return steps.size();
    }

    public String getStepPremodel(int i) {
        return steps.get(i).getPremodel();
    }

    public String getStepNextRule(int i) {
        return steps.get(i).getNextRule();
    }

    private void addPreModelAndNextRule() {
        if (schemeIsSAT()) {
            steps.add(
                    new TableauExecutionStep(
                    scheme.eval("(graph-make (machinestate-set-get state))"),
                    "sat", ""));
        } else {
            steps.add(
                    new TableauExecutionStep(
                    scheme.eval("(graph-make (machinestate-set-get state))"),
                    scheme.eval("(couplerulesigma-getrule couplerulesigma)"),
                    scheme.eval("(couplerulesigma-getinstanciedconditions couplerulesigma)")));
        }
    }

    private int getLastStep() {
        return steps.size() - 1;
    }

    public Object getStepSigma(int executionStep) {
        return steps.get(executionStep).getSigma();
    }

    public void setActionListener(ActionListener actionListener) {
        this.actionListener = actionListener;
        actionListener.actionPerformed(null);
    }
}
