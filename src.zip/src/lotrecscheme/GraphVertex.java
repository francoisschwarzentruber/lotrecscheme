/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lotrecscheme;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;

/**
 *
 * @author proprietaire
 */

public class GraphVertex {
    static int fontSizeVertexName = 13;
    static int fontSizeVertexContents = 16;
    
    
    
    private String nom;
    private int formulasnbmax = 32;
    private ArrayList<String> formulas = null;
    private ArrayList<String> screenformulas = null;
    
    private Point position = null;
    
    private int width = 0;
    private int height = 0;
    private boolean mark = false;
    
    final private int rectangle_rayon = 8;
    private ArrayList<String> highlights_highlighted_formulas = null;
    final private Color highlight_color = new Color(0.5f, 0f, 0f);
    final private int margeInterieur = 12;
    
    GraphVertex(String nom)
    {
        this.nom = nom;
        position = new Point((int ) Math.round(Math.random() * 400), (int ) Math.round(Math.random() * 400));
        formulas = new ArrayList<String>();
        highlights_highlighted_formulas = new ArrayList<String>();
        screenformulas = new ArrayList<String>();
    }

    public void setNom(String nom) {
        this.nom = nom;
    }



    
    
    public void blabla_add(String cequejajoute)
    {
        if(formulas.contains(cequejajoute))
                return;
        
        int taille_maximale_formule = 64;
        formulas.add(cequejajoute);
        if(cequejajoute.length() < taille_maximale_formule)
             screenformulas.add(SchemeEdit.scheme_convertir_avec_des_caracteres_dessins(cequejajoute));
        else
             screenformulas.add(SchemeEdit.scheme_convertir_avec_des_caracteres_dessins(cequejajoute.substring(0, taille_maximale_formule) + "..."));
        
    }
    
    
     
     
     
    
    @Override
    public String toString()
    {
        return nom;
    }

    public void drawWhenUnderCursor(Graphics g) {
        drawShadow(g);
        drawContents(g, new Color(1.0f, 0.9f, 0.5f) );

        g.setColor(Color.BLACK);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(2.0f));
        drawContourRoundRect(g);
    }


    public void drawWhenHighLighted(Graphics g) {
        drawShadow(g);
        drawContents(g, new Color(1.0f, 0.7f, 0.7f) );

        g.setColor(highlight_color);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(3.0f));
        drawContourRoundRect(g);

    }
    
    
    private void drawContourRoundRect(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        int w = getWidth();
        int h = getHeight();
        
        
        g.drawRoundRect(position.x - w/2, position.y - h/2, w, h,
                        rectangle_rayon, rectangle_rayon);
    }


    
    
    
    public void highlights_reset()
    {
        highlights_highlighted_formulas = new ArrayList<String>();
    }
    
    public void highlights_highlightformula(String formula)
    {
        highlights_highlighted_formulas.add(formula);
    }
    
    
    public boolean highlights_is_highlighted_formula(String formula)
    {
        return (highlights_highlighted_formulas.contains(formula));
    }
    

    String getName() {
        return nom;
    }
    
    
    String getContents()
    {
        String s = "";
        for(String f: formulas)
        {
            s = s.concat(f).concat("\n\n");
        }
        return s;
    }
    
    
    
    public ArrayList<String> getFormulas()
    {
        return formulas;
    }
    
    public void setPositionMiddle(Point p)
    {
        position = p;
        
        if(position.x < getWidth() / 2)
            position.x = getWidth() / 2;
        
        if(position.y < getHeight() / 2)
            position.y = getHeight() / 2;
    }
    
    
    
    public Point getPosition()
    {
        return position;
    }

    boolean isMarked() {
        return mark;
    }

    void mark() {
        mark = true;
    }

    void setFormulas(ArrayList<String> contents) {
        formulas = new ArrayList<String>();
        screenformulas = new ArrayList<String>();
        for(String s : contents)
        {
            blabla_add(s);
        }
        
    }

    void unmark() {
        mark = false;
    }

    private void drawStringAtTheRight(Graphics g, String s, int x, int y) {
        g.drawString(s, x - g.getFontMetrics().stringWidth(s), y);
    }

    
    private void drawStringInTheMiddle(Graphics g, String s, int x, int y) {
        g.drawString(s, x - g.getFontMetrics().stringWidth(s) / 2, y);
    }
    
    
    public int getWidth()
    {
        return width;
    }
    
    
    public int getHeight()
    {
        return height;
    }
    
    
    public void widthHeightCompute(Graphics g)
    {
        
        int w = 0;
        g.setFont(new Font(g.getFont().getName(), 1, g.getFont().getSize()));
        
        
        int marge = g.getFont().getSize();
        
        for(int i = 0; i < Math.min(screenformulas.size(), formulasnbmax); i++)
        {
            String s = screenformulas.get(i);
            w = Math.max(w,g.getFontMetrics().stringWidth(s));
        }
        width = w + 2*marge;
        
        height = (Math.min(screenformulas.size(), formulasnbmax) + 1) * (g.getFontMetrics().getHeight()+3) + marge;
        
        width = Math.max(width, 64);
        height = Math.max(height, 48);
    }


    public void drawContents(Graphics g)
    {

    }




    public void drawContentsNormal(Graphics g)
    {
       // drawShadow(g);
        drawContents(g, new Color(1.0f, 1.0f, 0.5f) );
        
        
        
    }
    
    
    public void drawContour(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1.5f));
        drawContourRoundRect(g);
    }
    

    
    
    public boolean contains(Point p)
    {
        int w = getWidth();
        int h = getHeight();
        Rectangle r = new Rectangle(position.x - w/2, position.y - h/2, w, h);
        return r.contains(p);
    }
    
    public boolean interiorContains(Point p)
    {
        int w = getWidth()-margeInterieur*2;
        int h = getHeight()-margeInterieur*2;
        Rectangle r = new Rectangle(position.x - w/2, position.y - h/2, w, h);
        return r.contains(p);
    }
    
    
    public boolean almostcontains(Point p)
    {
        int w = getWidth()+4;
        int h = getHeight()+4;
        Rectangle r = new Rectangle(position.x - w/2, position.y - h/2, w, h);
        return r.contains(p);
    }
    
    public boolean contourContains(Point p)
    {
        return almostcontains(p) && !interiorContains(p);
    }

    private void drawShadow(Graphics g) {
        int w = getWidth();
        int h = getHeight();


        int shadow_decalx = 4;
        int shadow_decaly = 4;


        g.setColor(new Color(0.5f, 0.5f, 0.5f)); //gray
        g.fillRoundRect(position.x - w/2 + shadow_decalx, position.y - h/2 + shadow_decaly, w, h,
                        rectangle_rayon, rectangle_rayon);
    }

    private void drawContents(Graphics g, Color color) {
       int w = getWidth();
        int h = getHeight();


        g.setColor(color.brighter()); //light yellow
        g.fillRoundRect(position.x - w/2, position.y - h/2, w, h,
                        rectangle_rayon, rectangle_rayon);

        g.setColor(color); //light yellow
        g.fillRect(position.x - w/2 + margeInterieur,
                        position.y - h/2 + margeInterieur,
                        w - 2*margeInterieur,
                        h - 2*margeInterieur);


        g.setColor(Color.BLACK);

        int ynom = position.y - h/2;
        int xnom = position.x - w/2;
        //g.setFont(new Font(g.getFont().getName(), 0, g.getFont().getSize()));
        g.setFont(new Font("", 0, fontSizeVertexName));
        drawStringAtTheRight(g, nom, xnom, ynom);

        g.setFont(new Font("", 0, fontSizeVertexContents));
        int y = position.y - h/2 + g.getFontMetrics().getHeight();
        for(int i = Math.min(screenformulas.size(), formulasnbmax)-1; i >= 0 ; i--)
        {
            String s = screenformulas.get(i);

            if(highlights_is_highlighted_formula(s))
            {
                g.setColor(highlight_color);
                g.setFont(new Font(g.getFont().getName(), 1, g.getFont().getSize()));
            }
            else
            {       g.setColor(Color.BLACK);
                g.setFont(new Font(g.getFont().getName(), 0, g.getFont().getSize()));
            }

            drawStringInTheMiddle(g, s, position.x, y);
            y += g.getFontMetrics().getHeight();
        }
    }
    
    
}
