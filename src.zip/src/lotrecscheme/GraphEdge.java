/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lotrecscheme;

import java.awt.*;
import java.util.ArrayList;

/**
 *
 * @author proprietaire
 */
public class GraphEdge  {
    private String relationNameConcatenated = null;
    private ArrayList<String> relations_nom = null;
    final private GraphVertex depart;
    final private GraphVertex arrive;
    private boolean oriented = true;
    
    private Color [] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE,
                       Color.GRAY, Color.PINK, Color.MAGENTA};
    
    GraphEdge(String nom, GraphVertex depart, GraphVertex arrive )
    {
        this.relationNameConcatenated = nom;
        this.depart = depart;
        this.arrive = arrive;
        
        relations_nom = new ArrayList<String>();
        relations_nom.add(nom);
    }

    public GraphVertex getDepart() {
        return depart;
    }

    public GraphVertex getArrive() {
        return arrive;
    }


    
    
    @Override
    public String toString()
    {
        if(relationNameConcatenated == null)
            return "";
        else
            return relationNameConcatenated;
    }

    public void ajouterblabla(String arc_nom) {
        if(relations_nom.contains(arc_nom))
                return;
        relationNameConcatenated = relationNameConcatenated + ", " + arc_nom;
        relations_nom.add(arc_nom);
    }
    
    
    public ArrayList<String> getRelationsName()
    {
        return relations_nom;
    }
    
    public void setRelationsName(ArrayList<String> r)
    {
        relations_nom = new ArrayList<String>();
        
        if(r.size() > 1)
        {
            boolean changed = true;
            while(changed)
            {
                changed = relations_nom.remove("");
            }
            
        }
        
        if(r.isEmpty())
            r.add("");
        
        relationNameConcatenated = "";
        for(String s : r)
        {
            
            if(relationNameConcatenated.isEmpty())
            {
                ajouterblabla(s);
                relationNameConcatenated = s;
            }
            ajouterblabla(s);
        }
    }
    
    
    
    private Color getColorWithString(String s)
    {
        int v = 0;
        
        for(int i = 0; i < s.length(); i++)
        {
            v += s.charAt(i);
        }
        
        v = (v + s.length()) % colors.length;
        
        return colors[v];
    }
    
    
    private static void fleche(Graphics g,
            Point departpos,
            Point arrivepos,
            String label,
            boolean oriented)
    {
        g.drawLine(departpos.x, departpos.y, arrivepos.x, arrivepos.y);
        
        double lambda = 0.33;
        int arrowsymbolpositionx = (int) (lambda * departpos.x + (1 - lambda) * arrivepos.x);
        int arrowsymbolpositiony = (int) (lambda * departpos.y + (1 - lambda) * arrivepos.y);
        double l = 16;
        double t = 10;
        
        double anglefleche = 0.4;
        double angle = Math.atan2(-(arrivepos.y - departpos.y), -(arrivepos.x - departpos.x));
        
        if(oriented)
        {
            g.drawLine(arrowsymbolpositionx, arrowsymbolpositiony, arrowsymbolpositionx + (int) (l * Math.cos(angle + anglefleche)),
                    arrowsymbolpositiony  + (int) (l * Math.sin(angle + anglefleche)));

            g.drawLine(arrowsymbolpositionx, arrowsymbolpositiony, arrowsymbolpositionx + (int) (l * Math.cos(angle - anglefleche)),
                    arrowsymbolpositiony  + (int) (l * Math.sin(angle - anglefleche)));
        }
        
        g.drawString(label, arrowsymbolpositionx + 3 + (int) (t * Math.cos(angle)) -
                             g.getFontMetrics().stringWidth(label)/2,
                            arrowsymbolpositiony - 5 + (int) (t * Math.sin(angle)));
    }
    
    
    
    
    public Point getArrowPosition()
    {
        int arrowsymbolpositionx;
        int arrowsymbolpositiony;
        if(depart == arrive)
        {
            int x = depart.getPosition().x;
            int y = depart.getPosition().y;
            int width = Math.max(46, depart.getWidth());
            int height = Math.max(16, depart.getHeight());
            arrowsymbolpositionx = x + width / 2;
            arrowsymbolpositiony = y + height;
        }
        else
        {
        
            Point departpos = depart.getPosition();
            Point arrivepos = arrive.getPosition();
            double lambda = 0.33;
            arrowsymbolpositionx = (int) (lambda * departpos.x + (1 - lambda) * arrivepos.x);
            arrowsymbolpositiony = (int) (lambda * departpos.y + (1 - lambda) * arrivepos.y);

            
        }
        
        return new Point(arrowsymbolpositionx, arrowsymbolpositiony);
    }
    
    
    
    private static void arc_reflexif(Graphics g, int x, int y, int width, int height, String label)
    {
        width = Math.max(46, width);
        height = Math.max(16, height / 2 + 16);
        x = x - width / 4;
        width = width / 2;
        g.drawOval(x, y, width, height);
        
        double l = 8;
        double anglefleche = 0.4;
        
        int arrowsymbolpositionx = x + width / 2;
        int arrowsymbolpositiony = y + height;
        
        g.drawLine(arrowsymbolpositionx, arrowsymbolpositiony, arrowsymbolpositionx + (int) (l * Math.cos(0 + anglefleche)),
                arrowsymbolpositiony  + (int) (l * Math.sin(0 + anglefleche)));
        
        g.drawLine(arrowsymbolpositionx, arrowsymbolpositiony, arrowsymbolpositionx + (int) (l * Math.cos(0 - anglefleche)),
                arrowsymbolpositiony  + (int) (l * Math.sin(0 - anglefleche)));
        
        g.drawString(label, x+width, y+height);
    }
    
    
    private void drawEdge(Graphics g, float epaisseur)
    {
        Graphics2D g2 = (Graphics2D) g;

        g2.setStroke(new BasicStroke(epaisseur));
        g.setColor(getColorWithString(relationNameConcatenated));

        if(depart == arrive)
        {
            arc_reflexif(g, depart.getPosition().x, depart.getPosition().y,
                            depart.getWidth(),
                            depart.getHeight(),
                            relationNameConcatenated);


        }
        else
        {
            fleche(g, depart.getPosition(), arrive.getPosition(), relationNameConcatenated, oriented);

        }
    }
    
    public void draw(Graphics g)
    {
        drawEdge(g, 1.5f);
    }

    
    
    
    public boolean contains(Point p) {
        return getArrowPosition().distance(p)<22;
    }
   
    
    

    public GraphVertex getSource() {
        return depart;
    }
    
    
    public GraphVertex getDest() {
        return arrive;
    }

    public void setAsNotOriented() {
        oriented = false;
    }

    public void drawWhenUnderCursor(Graphics g) {
        drawEdge(g, 2.0f);
    }


}
