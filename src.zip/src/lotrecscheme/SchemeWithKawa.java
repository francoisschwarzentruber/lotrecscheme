/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lotrecscheme;

import gnu.mapping.Environment;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import kawa.standard.Scheme;

/**
 *
 * @author proprietaire
 */
public class SchemeWithKawa {
    //private final kawa.standard.Scheme scheme;

    private String errorMessage = null;




    public String popError()
    {
        String s = errorMessage;
        errorMessage = null;
        return s;
    }


    

    public SchemeWithKawa() {
       // scheme = new kawa.standard.Scheme();
        Scheme.registerEnvironment();
        Environment.setCurrent(new Scheme().getEnvironment());
        lotrec_load();

    }



    public void pushError(Throwable s)
    {
        errorMessage = s.toString();
        System.out.print(s);
    }


    
    public String evalDefine(String schemeCode)
    {
        try {
            return Scheme.eval(schemeCode, Environment.current()).toString();
           // StringWriter w = new StringWriter();
           // scheme.eval("(schemeCode, w);
          //  return w.toString();
        } catch (Throwable ex) {

            System.out.print("error scheme in evalDefine with : " + schemeCode);
            pushError(ex);
            return null;
        }
    }



    
    public String eval(String schemeCode)
    {
        try {
            return Scheme.eval("(format \"~a\" " + schemeCode + ")", Environment.current()).toString();
           // StringWriter w = new StringWriter();
           // scheme.eval("(schemeCode, w);
          //  return w.toString();
        } catch (Throwable ex) {
            System.out.print("error scheme in eval with : " + schemeCode);
            pushError(ex);
            return null;
        }
    }
    
   
    public void evalAndDoNotCareAboutTheResult(String schemeCode)
    {
        try {
 
            Scheme.eval(schemeCode, Environment.current());
        }
         catch (Throwable ex) {
            System.out.print("error scheme in evalAndDoNotCareAboutTheResult with : " + schemeCode);
            pushError(ex);
        
        }
        // StringWriter w = new StringWriter();
           // scheme.eval("(schemeCode, w);
          //  return w.toString();
    }


    static private void schemeLoad(final String schemeFileOrLibraryToLoad)
    {
        try {

        Scheme.eval("(load \"" + schemeFileOrLibraryToLoad + "\")", Environment.current());

        }
         catch (Throwable ex) {
            System.out.print("error scheme schemeLoad with : " + schemeFileOrLibraryToLoad);
            System.out.print(ex);

        }
        //apparemment ça charge un fichier qui se trouve dans C:\Users\Ancmin\Documents\NetbeansProjects\LotrecScheme
    }


    private void lotrec_load_compiledversion()
    {
         //schemeLoad("javax.swing.ImageIcon");
       // schemeLoad("engine.sets");
       // schemeLoad("sets.class");
        //schemeLoad("compiledfile.jar");
        schemeLoad("sets.jar");
        schemeLoad("machinestate.jar");
        schemeLoad("unification.jar");
        //ressourcescheme_charger("program/sets.scm");
       // ressourcescheme_charger("program/machinestate.scm");
       // ressourcescheme_charger("program/nondeterminism.scm");
        ressourcescheme_charger("program/element-generator.scm");
        ressourcescheme_charger("program/rule.scm");
      // ressourcescheme_charger("program/unification.scm");

        schemeLoad("lotreclight.jar");
       // ressourcescheme_charger("program/lotreclight.scm");

        ressourcescheme_charger("program/functions.scm");
        ressourcescheme_charger("program/main.scm");
        //schemeLoad("C://lotrecscheme//main.class");
    }


    private void lotrec_load()
    {
        ressourcescheme_charger("program/sets.scm");
        ressourcescheme_charger("program/machinestate.scm");
        
        ressourcescheme_charger("program/element-generator.scm");
        ressourcescheme_charger("program/rule.scm");
        ressourcescheme_charger("program/unification.scm");

        ressourcescheme_charger("program/lotreclight.scm");

        ressourcescheme_charger("program/functions.scm");
        ressourcescheme_charger("program/main.scm");

        ressourcescheme_charger("tableau_methods_files/K.scm");
    }
    

    
    public void fileLoad(String fileName)
    {
        fileName = fileName.replace("\\", "/");
        evalAndDoNotCareAboutTheResult("(load \"" + fileName + "\")");
    }


    
    
    @SuppressWarnings("static-access")
    public void ressourcescheme_charger(String filename)
    {   
        String s = null;
        
            
            try {
                s = TextFile.lire_dans_une_ressource_sans_les_load_descheme("resources/" + filename);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Scheme.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Scheme.class.getName()).log(Level.SEVERE, null, ex);
            }

           try {
            evalAndDoNotCareAboutTheResult(s);
                    } catch (Throwable ex) {
                      System.out.println("error in opening Scheme ressource " + filename);
            }
//            interpreter.interpret(
//            interpreter.compile( interpreter.read(s) )); marche pas

        
    }



    
    
}
