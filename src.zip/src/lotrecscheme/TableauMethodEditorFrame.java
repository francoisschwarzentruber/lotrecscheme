/*
 * TableauMethodEditorFrame.java
 *
 * Created on 25 avril 2009, 01:26
 */

package lotrecscheme;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.text.TabExpander;
import jscheme.JScheme;
import jscheme.SchemePair;



/**
 * 
 * @author  proprietaire
 */


public class TableauMethodEditorFrame extends javax.swing.JFrame {
    Scheme scheme = null;
    String rulesVariable = "rules";
    private String filename = null;
    
    
    /** Creates new form TableauMethodEditorFrame
     * @param scheme 
     */
    public TableauMethodEditorFrame(Scheme scheme) {
        initComponents();

        scrollPane.getVerticalScrollBar().setUnitIncrement(32);

        ((DropDownButton) cmdOpen).setPopupMenu(popupMenuLoad);
        ((DropDownButton) cmdOpen).addArrowButtonToToolBar(jToolBar1, 1);
        
        
        
        ((DropDownButton) cmdSaveDropDown).setPopupMenu(popupMenuSave);
        ((DropDownButton) cmdSaveDropDown).addArrowButtonToToolBar(jToolBar1, 3);
        
        
        ((DropDownButton) cmdRun).setPopupMenu(popupMenuRun);
        ((DropDownButton) cmdRun).addArrowButtonToToolBar(jToolBar1, 10);
        
        this.scheme = scheme;
        
        
        
        schemeToLoadLogicInGUI();
        
        
        addLogic("modal logic K", "tableau_methods_files/K.scm");
        addLogic("modal logic KD", "tableau_methods_files/KD.scm");
        addLogic("modal logic KT", "tableau_methods_files/KT.scm");
        addLogic("modal logic K4", "tableau_methods_files/K4.scm");
        addLogic("modal logic S4", "tableau_methods_files/S4.scm");
        addLogic("modal logic GL", "tableau_methods_files/GL.scm");
        addLogic("modal logic Grz", "tableau_methods_files/Grz.scm");

        addLogic("modal logic S4 with limit", "tableau_methods_files/S4limitbranch.scm");
        addLogic("modal logic S5", "tableau_methods_files/S5.scm");
        addLogic("modal logic KD45n", "tableau_methods_files/KD45n.scm");
        addLogic("modal logic graded KD45n", "tableau_methods_files/KD45ngraded.scm");
        addLogic("modal logic S5n", "tableau_methods_files/S5n.scm");
        addLogic("modal logic LTL", "tableau_methods_files/LTL.scm");
        addLogic("modal logic PDL", "tableau_methods_files/PDL.scm");
        addLogic("modal logic S5nPAL", "tableau_methods_files/S5nPAL.scm");
        addLogic("modal logic K + universal modality", "tableau_methods_files/K+universal.scm");
        addLogic("modal logic Kn + converse + universal modality", "tableau_methods_files/KnConvUniv.scm");
        addLogic("hybrid modal logic HL(@)", "tableau_methods_files/HL(@).scm");
        addLogic("modal logic K + global affectation [p :=_g ...]", "tableau_methods_files/K+globalaffectation.scm");
        addLogic("DEL (phi, phi', phi'')", "tableau_methods_files/compositionexclu.scm");
        addLogic("generalized DEL sequents", "tableau_methods_files/generalized_del_sequent_exclu.scm");


    }
    
    

    
    private void addLogic(final String logicName, final String logicFile)
    {
        final JMenuItem m = new JMenuItem(logicName);
        m.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                scheme.eval("(define examples '())");
                scheme.ressourcescheme_charger(logicFile);
                
                schemeToLoadLogicInGUI();
            }
        });
        popupMenuLoad.add(m);
    }
    
    
    
    private void examplesListLoad()
    {

        popupMenuRun.removeAll();
        
        
        Object listscheme = null;
        
        JScheme js = new JScheme();
        
        listscheme = scheme.eval("examples");

        if(listscheme == null)
        {
            return;
            //erreur
        }
        SchemePair sp = (SchemePair) js.eval("'" + listscheme.toString());
        
        while(sp.length() > 0)
        {
            final String schemeCodeExample = sp.first().toString();
             
        
            final AbstractButton m = new JMenuItem(GraphPanel.getIcon(schemeCodeExample));
           //m .add(gp);
            m.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                tableauMethodExecutionStart(schemeCodeExample);
            }
            
            
            });
            
            popupMenuRun.add(m);

            sp = (SchemePair) sp.getRest();
        }   


    }
    
    
    
    
    
    private void rulesListLoad()
    {
        panList.removeAll();
        
        Object listscheme = null;
        
        JScheme js = new JScheme();
        
        listscheme = scheme.eval(rulesVariable);

        if(listscheme == null)
        {
            return;
            //erreur
        }
        SchemePair sp = (SchemePair) js.eval("'" + listscheme.toString());
        
        while(sp.length() > 0)
        {
             RulePanel rulePanel = new RulePanel(scheme);
             if(sp.first().toString().startsWith("("))
             {
                 rulePanel.load(sp.first());
                 rulePanel.setComponentPopupMenu(jPopupMenuRule);
                 panList.add(rulePanel);
             }
             
             sp = (SchemePair) sp.getRest();
        }   
             
    }
    
    
    private void panelListRedim()
    {
//        int h = 0;
//        for(Component c :panList.getComponents())
//        {
//            h += c.getHeight();
//        }
//        Dimension d = new Dimension(scrollPane.getWidth()-32, h);
//        panList.setPreferredSize(d);
//        panList.setSize(d);
//     
        
         

        
        scrollPane.doLayout();
        panList.doLayout();
        for(Component c :panList.getComponents())
        {
            c.doLayout();
            ((RulePanel) c).recalc();
            c.doLayout();

        }

         
        panList.doLayout();
        scrollPane.validate();
        scrollPane.revalidate();
        panList.revalidate();
        
         scrollPane.repaint();
        
    }
    
    
    
    
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenuRule = new javax.swing.JPopupMenu();
        mnuRemoveRule = new javax.swing.JMenuItem();
        mnuAddRule = new javax.swing.JMenu();
        mnuAddRuleFail = new javax.swing.JMenuItem();
        mnuAddRuleDet = new javax.swing.JMenuItem();
        mnuAddRuleNonDet = new javax.swing.JMenuItem();
        mnuShiftTop = new javax.swing.JMenuItem();
        mnuShiftDown = new javax.swing.JMenuItem();
        mnuCopyRule = new javax.swing.JMenuItem();
        mnuRuleDebug = new javax.swing.JMenuItem();
        popupMenuLoad = new javax.swing.JPopupMenu();
        popupMenuSave = new javax.swing.JPopupMenu();
        mnuSave = new javax.swing.JMenuItem();
        mnuSaveAs = new javax.swing.JMenuItem();
        jToolBar1 = new javax.swing.JToolBar();
        cmdNew = new javax.swing.JButton();
        cmdOpen = new DropDownButton();
        cmdSaveDropDown = new DropDownButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        cmdNewRuleFail = new javax.swing.JButton();
        cmdNewRuleDet = new javax.swing.JButton();
        cmdNewRuleNonDet = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        cmdRun = new DropDownButton();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        scrollPane = new javax.swing.JScrollPane();
        panList = new javax.swing.JPanel();

        jPopupMenuRule.setName("jPopupMenuRule"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(lotrecscheme.LispuApp.class).getContext().getResourceMap(TableauMethodEditorFrame.class);
        mnuRemoveRule.setIcon(resourceMap.getIcon("mnuRemoveRule.icon")); // NOI18N
        mnuRemoveRule.setText(resourceMap.getString("mnuRemoveRule.text")); // NOI18N
        mnuRemoveRule.setName("mnuRemoveRule"); // NOI18N
        mnuRemoveRule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuRemoveRuleActionPerformed(evt);
            }
        });
        jPopupMenuRule.add(mnuRemoveRule);

        mnuAddRule.setIcon(resourceMap.getIcon("mnuAddRule.icon")); // NOI18N
        mnuAddRule.setText(resourceMap.getString("mnuAddRule.text")); // NOI18N
        mnuAddRule.setName("mnuAddRule"); // NOI18N

        mnuAddRuleFail.setIcon(resourceMap.getIcon("mnuAddRuleFail.icon")); // NOI18N
        mnuAddRuleFail.setText(resourceMap.getString("mnuAddRuleFail.text")); // NOI18N
        mnuAddRuleFail.setName("mnuAddRuleFail"); // NOI18N
        mnuAddRuleFail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAddRuleFailActionPerformed(evt);
            }
        });
        mnuAddRule.add(mnuAddRuleFail);

        mnuAddRuleDet.setIcon(resourceMap.getIcon("mnuAddRuleDet.icon")); // NOI18N
        mnuAddRuleDet.setText(resourceMap.getString("mnuAddRuleDet.text")); // NOI18N
        mnuAddRuleDet.setName("mnuAddRuleDet"); // NOI18N
        mnuAddRuleDet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAddRuleDetActionPerformed(evt);
            }
        });
        mnuAddRule.add(mnuAddRuleDet);

        mnuAddRuleNonDet.setIcon(resourceMap.getIcon("mnuAddRuleNonDet.icon")); // NOI18N
        mnuAddRuleNonDet.setText(resourceMap.getString("mnuAddRuleNonDet.text")); // NOI18N
        mnuAddRuleNonDet.setName("mnuAddRuleNonDet"); // NOI18N
        mnuAddRuleNonDet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAddRuleNonDetActionPerformed(evt);
            }
        });
        mnuAddRule.add(mnuAddRuleNonDet);

        jPopupMenuRule.add(mnuAddRule);

        mnuShiftTop.setIcon(resourceMap.getIcon("mnuShiftTop.icon")); // NOI18N
        mnuShiftTop.setText(resourceMap.getString("mnuShiftTop.text")); // NOI18N
        mnuShiftTop.setName("mnuShiftTop"); // NOI18N
        mnuShiftTop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuShiftTopActionPerformed(evt);
            }
        });
        jPopupMenuRule.add(mnuShiftTop);

        mnuShiftDown.setIcon(resourceMap.getIcon("mnuShiftDown.icon")); // NOI18N
        mnuShiftDown.setText(resourceMap.getString("mnuShiftDown.text")); // NOI18N
        mnuShiftDown.setName("mnuShiftDown"); // NOI18N
        mnuShiftDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuShiftDownActionPerformed(evt);
            }
        });
        jPopupMenuRule.add(mnuShiftDown);

        mnuCopyRule.setText(resourceMap.getString("mnuCopyRule.text")); // NOI18N
        mnuCopyRule.setName("mnuCopyRule"); // NOI18N
        mnuCopyRule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCopyRuleActionPerformed(evt);
            }
        });
        jPopupMenuRule.add(mnuCopyRule);

        mnuRuleDebug.setText(resourceMap.getString("mnuRuleDebug.text")); // NOI18N
        mnuRuleDebug.setName("mnuRuleDebug"); // NOI18N
        mnuRuleDebug.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuRuleDebugActionPerformed(evt);
            }
        });
        jPopupMenuRule.add(mnuRuleDebug);

        popupMenuLoad.setName("popupMenuLoad"); // NOI18N

        popupMenuSave.setName("popupMenuSave"); // NOI18N

        mnuSave.setIcon(resourceMap.getIcon("mnuSave.icon")); // NOI18N
        mnuSave.setText(resourceMap.getString("mnuSave.text")); // NOI18N
        mnuSave.setName("mnuSave"); // NOI18N
        mnuSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuSaveActionPerformed(evt);
            }
        });
        popupMenuSave.add(mnuSave);

        mnuSaveAs.setIcon(resourceMap.getIcon("mnuSaveAs.icon")); // NOI18N
        mnuSaveAs.setText(resourceMap.getString("mnuSaveAs.text")); // NOI18N
        mnuSaveAs.setName("mnuSaveAs"); // NOI18N
        mnuSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuSaveAsActionPerformed(evt);
            }
        });
        popupMenuSave.add(mnuSaveAs);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(resourceMap.getString("Form.title")); // NOI18N
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsListener() {
            public void ancestorMoved(java.awt.event.HierarchyEvent evt) {
            }
            public void ancestorResized(java.awt.event.HierarchyEvent evt) {
                formAncestorResized(evt);
            }
        });
        addWindowStateListener(new java.awt.event.WindowStateListener() {
            public void windowStateChanged(java.awt.event.WindowEvent evt) {
                formWindowStateChanged(evt);
            }
        });
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.PAGE_AXIS));

        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);
        jToolBar1.setFont(resourceMap.getFont("jToolBar1.font")); // NOI18N
        jToolBar1.setName("jToolBar1"); // NOI18N

        cmdNew.setFont(resourceMap.getFont("cmdNew.font")); // NOI18N
        cmdNew.setIcon(resourceMap.getIcon("cmdNew.icon")); // NOI18N
        cmdNew.setText(resourceMap.getString("cmdNew.text")); // NOI18N
        cmdNew.setToolTipText(resourceMap.getString("cmdNew.toolTipText")); // NOI18N
        cmdNew.setFocusable(false);
        cmdNew.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdNew.setName("cmdNew"); // NOI18N
        cmdNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNewActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdNew);

        cmdOpen.setIcon(resourceMap.getIcon("cmdOpen.icon")); // NOI18N
        cmdOpen.setText(resourceMap.getString("cmdOpen.text")); // NOI18N
        cmdOpen.setToolTipText(resourceMap.getString("cmdOpen.toolTipText")); // NOI18N
        cmdOpen.setFocusable(false);
        cmdOpen.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdOpen.setName("cmdOpen"); // NOI18N
        cmdOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdOpenActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdOpen);

        cmdSaveDropDown.setIcon(resourceMap.getIcon("cmdSaveDropDown.icon")); // NOI18N
        cmdSaveDropDown.setText(resourceMap.getString("cmdSaveDropDown.text")); // NOI18N
        cmdSaveDropDown.setToolTipText(resourceMap.getString("cmdSaveDropDown.toolTipText")); // NOI18N
        cmdSaveDropDown.setComponentPopupMenu(popupMenuSave);
        cmdSaveDropDown.setFocusable(false);
        cmdSaveDropDown.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cmdSaveDropDown.setName("cmdSaveDropDown"); // NOI18N
        cmdSaveDropDown.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cmdSaveDropDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdSaveDropDownActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdSaveDropDown);

        jSeparator1.setMaximumSize(new java.awt.Dimension(6, 32));
        jSeparator1.setName("jSeparator1"); // NOI18N
        jToolBar1.add(jSeparator1);

        cmdNewRuleFail.setIcon(resourceMap.getIcon("cmdNewRuleFail.icon")); // NOI18N
        cmdNewRuleFail.setText(resourceMap.getString("cmdNewRuleFail.text")); // NOI18N
        cmdNewRuleFail.setToolTipText(resourceMap.getString("cmdNewRuleFail.toolTipText")); // NOI18N
        cmdNewRuleFail.setFocusable(false);
        cmdNewRuleFail.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cmdNewRuleFail.setName("cmdNewRuleFail"); // NOI18N
        cmdNewRuleFail.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        cmdNewRuleFail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNewRuleFailActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdNewRuleFail);

        cmdNewRuleDet.setIcon(resourceMap.getIcon("cmdNewRuleDet.icon")); // NOI18N
        cmdNewRuleDet.setText(resourceMap.getString("cmdNewRuleDet.text")); // NOI18N
        cmdNewRuleDet.setToolTipText(resourceMap.getString("cmdNewRuleDet.toolTipText")); // NOI18N
        cmdNewRuleDet.setFocusable(false);
        cmdNewRuleDet.setName("cmdNewRuleDet"); // NOI18N
        cmdNewRuleDet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNewRuleDetActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdNewRuleDet);

        cmdNewRuleNonDet.setIcon(resourceMap.getIcon("cmdNewRuleNonDet.icon")); // NOI18N
        cmdNewRuleNonDet.setText(resourceMap.getString("cmdNewRuleNonDet.text")); // NOI18N
        cmdNewRuleNonDet.setToolTipText(resourceMap.getString("cmdNewRuleNonDet.toolTipText")); // NOI18N
        cmdNewRuleNonDet.setName("cmdNewRuleNonDet"); // NOI18N
        cmdNewRuleNonDet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNewRuleNonDetActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdNewRuleNonDet);

        jSeparator2.setMaximumSize(new java.awt.Dimension(6, 32));
        jSeparator2.setName("jSeparator2"); // NOI18N
        jToolBar1.add(jSeparator2);

        cmdRun.setIcon(resourceMap.getIcon("cmdRun.icon")); // NOI18N
        cmdRun.setText(resourceMap.getString("cmdRun.text")); // NOI18N
        cmdRun.setToolTipText(resourceMap.getString("cmdRun.toolTipText")); // NOI18N
        cmdRun.setFocusable(false);
        cmdRun.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        cmdRun.setName("cmdRun"); // NOI18N
        cmdRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdRunActionPerformed(evt);
            }
        });
        jToolBar1.add(cmdRun);

        jButton2.setIcon(resourceMap.getIcon("jButton2.icon")); // NOI18N
        jButton2.setText(resourceMap.getString("jButton2.text")); // NOI18N
        jButton2.setToolTipText(resourceMap.getString("jButton2.toolTipText")); // NOI18N
        jButton2.setFocusable(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setName("jButton2"); // NOI18N
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton2);

        jButton1.setIcon(resourceMap.getIcon("jButton1.icon")); // NOI18N
        jButton1.setText(resourceMap.getString("jButton1.text")); // NOI18N
        jButton1.setToolTipText(resourceMap.getString("jButton1.toolTipText")); // NOI18N
        jButton1.setName("jButton1"); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jToolBar1.add(jButton1);

        getContentPane().add(jToolBar1);

        scrollPane.setComponentPopupMenu(jPopupMenuRule);
        scrollPane.setName("scrollPane"); // NOI18N
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 400));

        panList.setAutoscrolls(true);
        panList.setComponentPopupMenu(jPopupMenuRule);
        panList.setName("panList"); // NOI18N
        panList.setLayout(new javax.swing.BoxLayout(panList, javax.swing.BoxLayout.PAGE_AXIS));
        scrollPane.setViewportView(panList);

        getContentPane().add(scrollPane);
    }// </editor-fold>//GEN-END:initComponents

private void formAncestorResized(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_formAncestorResized
// TODO add your handling code here:
    panelListRedim();
}//GEN-LAST:event_formAncestorResized

private void formWindowStateChanged(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowStateChanged
// TODO add your handling code here:
    panelListRedim();
}//GEN-LAST:event_formWindowStateChanged

private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
// TODO add your handling code here:
    panelListRedim();
}//GEN-LAST:event_formComponentResized

private void cmdNewRuleDetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNewRuleDetActionPerformed
     RulePanel rulePanel = new RulePanel(scheme);
     rulePanel.load("(primitiverule (condition ((world A))) (add ()))");
     rulePanel.setComponentPopupMenu(jPopupMenuRule);
     panList.add(rulePanel);
     panelListRedim();
}//GEN-LAST:event_cmdNewRuleDetActionPerformed



private String getSchemeCode()
{
    String s = "(define rules '(";
     
     for(Component c : panList.getComponents())
     {
         s = s + ((RulePanel) c).getSchemeCode() + "\n\n\n";
     }
     s = s + "))\n\n";
         s = SchemeEdit.scheme_convertir_entextebrut(s);
         
     return s;
}


private void interfaceSave()
{
    if(!isOK())
    {
        JOptionPane.showMessageDialog(this, "One rule is not correct. Probably one condition is not correct (problem of parenthesis).");
        return;
    }


    if(filename!= null) {
        save();
    }
        else
        {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save a scheme file...");

            if(fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                setFileName(fc.getSelectedFile().getAbsolutePath());
                save();
            }
        }
    
    

        scheme.evalDefine(getSchemeCode());

}



private void interfaceSaveAs()
{
    if(!isOK())
    {
        JOptionPane.showMessageDialog(this, "One rule is not correct. Probably one condition is not correct (problem of parenthesis).");
        return;
    }

    
    JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save a scheme file...");

            if(fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                setFileName(fc.getSelectedFile().getAbsolutePath());
                save();
            }

            scheme.evalDefine(getSchemeCode());

}

private void mnuRemoveRuleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuRemoveRuleActionPerformed
// TODO add your handling code here:
    
    panList.remove(jPopupMenuRule.getInvoker());
    panelListRedim();
}//GEN-LAST:event_mnuRemoveRuleActionPerformed


private int getRulePanelIndice(Component c)
{
     for(int i = 0; i < panList.getComponentCount(); i++)
     {
         if(panList.getComponent(i) == c)
             return i;
     }
     
     return -1;
}


private RulePanel newRulePanel(String schemecode)
{
     RulePanel rulePanel = new RulePanel(scheme);
     rulePanel.load(schemecode);
     rulePanel.setComponentPopupMenu(jPopupMenuRule);
     
     return rulePanel;
}

private void mnuAddRuleDetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAddRuleDetActionPerformed
// TODO add your handling code here:
     panList.add(newRulePanel("(primitiverule (condition ((world A))) (add ()))"),
                 getRulePanelIndice(jPopupMenuRule.getInvoker())+1);
     
     panelListRedim();
}//GEN-LAST:event_mnuAddRuleDetActionPerformed

private void mnuShiftTopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuShiftTopActionPerformed
         int i = getRulePanelIndice(jPopupMenuRule.getInvoker());
         
         if(i <= 0)
             return;
         
         Component c = panList.getComponent(i);
         
         panList.remove(c);
         panList.add(c, i-1);
         panelListRedim();
}//GEN-LAST:event_mnuShiftTopActionPerformed

private void mnuShiftDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuShiftDownActionPerformed
         int i = getRulePanelIndice(jPopupMenuRule.getInvoker());
         
         if(i >= panList.getComponentCount() - 1)
             return;
         
         Component c = panList.getComponent(i);
         
         panList.remove(c);
         panList.add(c, i+1);
         panelListRedim();
}//GEN-LAST:event_mnuShiftDownActionPerformed

private void cmdNewRuleNonDetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNewRuleNonDetActionPerformed
     panList.add(newRulePanel("(primitiverule (condition ((world A))) (add-nondeterminist () ()))"),
                 getRulePanelIndice(jPopupMenuRule.getInvoker()));
     panelListRedim();
}//GEN-LAST:event_cmdNewRuleNonDetActionPerformed

private void cmdOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdOpenActionPerformed
    JFileChooser fc = new JFileChooser();
    fc.setDialogTitle("Load a tableau method...");
    if(fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
    {

                setFileName(fc.getSelectedFile().getAbsolutePath());
                scheme.fileLoad(filename);
                schemeToLoadLogicInGUI();




    }
}//GEN-LAST:event_cmdOpenActionPerformed

private void mnuSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSaveActionPerformed
// TODO add your handling code here:
    interfaceSave();
}//GEN-LAST:event_mnuSaveActionPerformed

private void mnuSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSaveAsActionPerformed
    interfaceSaveAs();
}//GEN-LAST:event_mnuSaveAsActionPerformed

private void cmdNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNewActionPerformed
// TODO add your handling code here:
    panList.removeAll();
    filename = null;
    panelListRedim();
}//GEN-LAST:event_cmdNewActionPerformed

private void cmdNewRuleFailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNewRuleFailActionPerformed
// TODO add your handling code here:
    panList.add(newRulePanel("(primitiverule (condition ((world A)(formula A bottom)))   (add ((halt)) ) )"),
                 getRulePanelIndice(jPopupMenuRule.getInvoker())+1);
     panelListRedim();
}//GEN-LAST:event_cmdNewRuleFailActionPerformed

private void mnuAddRuleFailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAddRuleFailActionPerformed
// TODO add your handling code here:
    panList.add(newRulePanel("(primitiverule (condition ((world A))) (add ((halt)) ))"),
                 getRulePanelIndice(jPopupMenuRule.getInvoker())+1);
     
     panelListRedim();
}//GEN-LAST:event_mnuAddRuleFailActionPerformed

private void mnuAddRuleNonDetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAddRuleNonDetActionPerformed
// TODO add your handling code here:
    panList.add(newRulePanel("(primitiverule (condition ((world A))) (add-nondeterminist () ()))"),
                 getRulePanelIndice(jPopupMenuRule.getInvoker())+1);
     
     panelListRedim();
}//GEN-LAST:event_mnuAddRuleNonDetActionPerformed

private void cmdRunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdRunActionPerformed
// TODO add your handling code here:
    scheme.evalDefine(getSchemeCode());
    TableauMethodExecutionFrame t = new TableauMethodExecutionFrame(scheme);
    t.setVisible(true);
}//GEN-LAST:event_cmdRunActionPerformed


void tableauMethodExecutionStart()
{
    scheme.evalDefine(getSchemeCode());
    TableauMethodExecutionFrame t = new TableauMethodExecutionFrame(scheme);
    t.setVisible(true);
}


void tableauMethodExecutionStart(String example)
{
    scheme.evalDefine(getSchemeCode());
    TableauMethodExecutionFrame t = new TableauMethodExecutionFrame(scheme);
    t.setGraphToStart(example);
    t.start();
    t.setVisible(true);
}


private void cmdSaveDropDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdSaveDropDownActionPerformed
// TODO add your handling code here:
    interfaceSave();
}//GEN-LAST:event_cmdSaveDropDownActionPerformed

private void mnuCopyRuleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCopyRuleActionPerformed
    // TODO add your handling code here:
    RulePanel rulePanel = (RulePanel) jPopupMenuRule.getInvoker();
    panList.add(newRulePanel(rulePanel.getSchemeCode()),
                 getRulePanelIndice(jPopupMenuRule.getInvoker()));
    panelListRedim();
}//GEN-LAST:event_mnuCopyRuleActionPerformed

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    Help.show("index.html");
}//GEN-LAST:event_jButton1ActionPerformed

    private void mnuRuleDebugActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuRuleDebugActionPerformed
        scheme.evalDefine(getSchemeCode());
        TableauMethodExecutionFrame t = new TableauMethodExecutionFrame(scheme);
        t.setVisible(true);
        
        RulePanel rulePanel = (RulePanel) jPopupMenuRule.getInvoker();
        t.setGraphToStart(scheme.eval("(free-variables-instanciate '" + rulePanel.getConditions() + ")"));
    }//GEN-LAST:event_mnuRuleDebugActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        (new FrameSchemeEvaluator(scheme)).setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new TableauMethodEditorFrame(new Scheme()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmdNew;
    private javax.swing.JButton cmdNewRuleDet;
    private javax.swing.JButton cmdNewRuleFail;
    private javax.swing.JButton cmdNewRuleNonDet;
    private javax.swing.JButton cmdOpen;
    private javax.swing.JButton cmdRun;
    private javax.swing.JButton cmdSaveDropDown;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPopupMenu jPopupMenuRule;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JMenu mnuAddRule;
    private javax.swing.JMenuItem mnuAddRuleDet;
    private javax.swing.JMenuItem mnuAddRuleFail;
    private javax.swing.JMenuItem mnuAddRuleNonDet;
    private javax.swing.JMenuItem mnuCopyRule;
    private javax.swing.JMenuItem mnuRemoveRule;
    private javax.swing.JMenuItem mnuRuleDebug;
    private javax.swing.JMenuItem mnuSave;
    private javax.swing.JMenuItem mnuSaveAs;
    private javax.swing.JMenuItem mnuShiftDown;
    private javax.swing.JMenuItem mnuShiftTop;
    private javax.swing.JPanel panList;
    private javax.swing.JPopupMenu popupMenuLoad;
    private javax.swing.JPopupMenu popupMenuSave;
    private javax.swing.JScrollPane scrollPane;
    // End of variables declaration//GEN-END:variables

    final private javax.swing.JPopupMenu popupMenuRun = new javax.swing.JPopupMenu();
    
    
    
    private void save() {
        try {
        TextFile.string_ecrire_dans_fichier(getSchemeCode(),
                                   filename);

    } catch (Exception ex) {
        Logger.getLogger(TextFile.class.getName()).log(Level.SEVERE, null, ex);
    }
        
    }
    // End of variables declaration

    private void setFileName(String filename) {
        this.filename = filename;
        if(this.filename == null)
        {
            this.setTitle("Tableau method editor - Unsaved tableau method");
        }
        else
        {
            this.setTitle("Tableau method editor - " + filename);
        }
        
    }

    private boolean isOK() {
        for(Component c : panList.getComponents())
        {
            if(c instanceof RulePanel)
            {
                if(!((RulePanel) c).isOK())
                    return false;
            }
        }
        return true;
    }

    private void schemeToLoadLogicInGUI() {
         rulesListLoad();
         examplesListLoad();       
         panelListRedim();
    }

}


