/*
 * GraphPanel.java
 *
 * Created on 29 août 2008, 18:55
 */

package lotrecscheme;


import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import jscheme.JScheme;
import jscheme.SchemePair;















/**
 * This panel enables to draw a graph.
 * @author Ancmin
 */
public class GraphPanel extends javax.swing.JPanel {

    private ArrayList<GraphVertex> vertices = null;
    private ArrayList<GraphEdge> edges = null;
    private ArrayList<GraphEdge> edgesextra = null;
    private GraphVertex graphVertexCurrent = null;
    private GraphEdge graphEdgeCurrent = null;
    private GraphVertex initialVertex = null;
    private boolean canMoveVertices = true;
    private boolean canVerticeDialogToSeeContents = true;
//    private boolean preferred_size_fixed = false;
    private boolean optimizedlayoutforrules = true;
    
  //  private ImageIcon imgBackground = new ImageIcon(getClass().getResource("resources/ciel_bleu.jpg"));
    
    
    /** Creates new form GraphPanel */
    public GraphPanel() {
        initComponents();
        
        vertices = new ArrayList<GraphVertex>();    
        edges = new ArrayList<GraphEdge>();
        edgesextra = new ArrayList<GraphEdge>();
        setDoubleBuffered(true);
        //pour éviter des clignotements
        
    }
    
    
    
    public GraphPanel(String schemeSetOfTerms)
    {
        this();
        graphe_remplir(schemeSetOfTerms);
    }
    
    public void setNoOptimizedLayoutButClassicalTree()
    {
        optimizedlayoutforrules = false;
    }
    
    public void modifierSourisCurseur(String img, Point hotSpot){
         //recupere le Toolkit
         Toolkit tk = Toolkit.getDefaultToolkit();
         //sur ce dernier lire le fichier avec "getClass().getRessource" pour
         //pouvoir l'ajouter a un .jar
         Image image= tk.getImage(getClass().getResource(img));
         //modifi le curseur avec la nouvelle image,en le posissionant grace hotSpot
         //et en lui donnant le nom "X"
         Cursor c = tk.createCustomCursor(image,hotSpot,"X");
         //puis on l'associe au Panel
         setCursor(c);
     }
    
     public void modifierSourisCurseurCrayon()
     {
         modifierSourisCurseur("resources/crayon.png", new Point(2, 30));
     }

     public void modifierSourisCurseurGomme()
     {
         modifierSourisCurseur("resources/gomme.png", new Point(8, 26));
     }  
     
     
     public void modifierSourisCurseurMain()
     {
         modifierSourisCurseur("resources/main.png", new Point(4, 0));
     } 
     
     
     public void modifierSourisCurseurNormal()
     {
         setCursor(Cursor.getDefaultCursor());
     } 
     
    public void canMoveVerticesSet(boolean b)
    {
        canMoveVertices = b;
    }

    public void graphLayoutCompute() {
        int w = getWidth();
        int h = getHeight();
        
        if(w == 0) {
            w = 100;
        }
        if(h == 0) {
            h = 100;
        }
        
        if((vertices.size() == 1) && optimizedlayoutforrules)
        {
            vertices.get(0).setPositionMiddle(new Point(w / 2, h / 2));
        }
        else if((vertices.size() == 2) && optimizedlayoutforrules)
        {
            vertices.get(0).setPositionMiddle(new Point(w / 4, h / 2));
            vertices.get(1).setPositionMiddle(new Point(3 * w / 4, h / 2));
        }
        else if((vertices.size() == 3) && optimizedlayoutforrules)
        {
            vertices.get(0).setPositionMiddle(new Point(w / 4, h / 4));
            vertices.get(1).setPositionMiddle(new Point(3 * w / 4, h / 4));
            vertices.get(2).setPositionMiddle(new Point(w / 2, 3 * h / 4));
        }
        else if((vertices.size() == 4) && optimizedlayoutforrules)
        {
            vertices.get(0).setPositionMiddle(new Point(w / 4, h / 4));
            vertices.get(1).setPositionMiddle(new Point(3 * w / 4, h / 4));
            vertices.get(2).setPositionMiddle(new Point(3 * w / 4, 3 * h / 4));
            vertices.get(3).setPositionMiddle(new Point(w / 4, 3 * h / 4));
        }
        else //if(!preferred_size_fixed)
        {
            for(GraphVertex v : vertices)
            {
                if(getGraphics() != null) {
                    v.widthHeightCompute(getGraphics());
                }
                v.setPositionMiddle(new Point(0, 0));


            }
            unmarkAllNodesAsNotTreated();

            final GraphVertex initialVertexLayout;

            if(initialVertex != null) {
                initialVertexLayout = initialVertex;
            }
            else {
                initialVertexLayout = initialVertexComputeGet();
            }

            GraphVertex n = initialVertexLayout;

            if(n == null) {
                n = getNodeNextRoot();
            }

            int x = 32;
            while(n != null)
            {
                layoutarbresub(n,
                               n.getWidth() / 2 + x,
                                n.getHeight() / 2 + 32);

                n = initialVertexComputeGet();

                x = getMaxPositionX() + 32;
            }
            
        }
        setPreferredSize(getPreferredSize());
    }

    public void graphe_initialiser() {
        removeAll();
        initialVertex = null;
        vertices = new ArrayList<GraphVertex>();    
        edges = new ArrayList<GraphEdge>(); 
        edgesextra = new ArrayList<GraphEdge>(); 
        highlights_reset();
    }

    
    boolean isInteger(String s)
    {
        try
        {
             Integer.parseInt(s);
             return true;
        }
        catch(NumberFormatException e)
        {
            return false;
        }
    }

    public GraphVertex getVertex(String name) {
        return sommet_get(name);
    }

    private GraphVertex initialVertexComputeGet() {
        if(sommet_existetil("n1"))
            if(!sommet_get("n1").isMarked())
                return sommet_get("n1");

        if(sommet_existetil("n2"))
            if(!sommet_get("n2").isMarked())
                return sommet_get("n2");

        if(sommet_existetil("(n1 n2)"))
            if(!sommet_get("(n1 n2)").isMarked())
                return sommet_get("(n1 n2)");

        return getNodeNextRoot();
//        if(vertices.size() > 0)
//
//            return vertices.get(0);
//        else
//            return null;
    }
    
    
    private boolean isNomSommetVariable()
    {
        if(vertices.isEmpty())
        {
            return false;
            
        }
        else
        {
            return isUpperCase(vertices.get(0).getName());
        }
    }
    
    public String sommet_getnouveaunom()
    {
        if(isNomSommetVariable())
        {
            char nompotentiel = 'A';
            for(nompotentiel = 'A'; ; nompotentiel++)
            {
                if(!sommet_existetil(String.valueOf(nompotentiel)))
                    return String.valueOf(nompotentiel);
            }
        }
        else
        {
            int i = 1;
            for(i = 1; ; i++)
            {
                if(!sommet_existetil("w" + String.valueOf(i)))
                    return String.valueOf("w" + i);
            }
        }

        
    }
    
    
    public GraphVertex sommet_ajouter() {
        return sommet_ajouter(sommet_getnouveaunom());
    }
    
    
    public GraphVertex sommet_contoursouscurseur(Point p)
    {
        for(GraphVertex v : vertices)
        {
            if(v.contourContains(p))
                return v;
        }
        return null;
    }
    
    
    public GraphVertex sommet_souscurseur(Point p)
    {
        for(GraphVertex v : vertices)
        {
            if(v.contains(p))
                return v;
        }
        return null;
    }
    
    /**
     *
     * @param p
     * @return the edge under the point p. If there is no edge under the point p, return null.
     */
    public GraphEdge arc_souscurseur(Point p)
    {
        for(GraphEdge e : edges)
        {
            if(e.contains(p))
                return e;
        }
        return null;
    }
    
    public GraphVertex sommet_interiorsouscurseur(Point p)
    {
        for(GraphVertex v : vertices)
        {
            if(v.interiorContains(p))
                return v;
        }
        return null;
    }


    void arc_supprimer(GraphEdge e) {
        edges.remove(e);
    }

    void canVerticeDialogToSeeContentsSet(boolean b) {
        canVerticeDialogToSeeContents = b;
    }

    ArrayList<GraphVertex> getVertices() {
        return vertices;
    }
    
    
    ArrayList<GraphEdge> getEdges() {
        return edges;
    }

    boolean isModeDeplacementNoeud() {
        return graphVertexCurrent != null;
    }

    void recalc() {
        graphLayoutCompute();
    }

    void setCurrentVertex(GraphVertex sommet) {
        graphVertexCurrent = sommet;
    }


    GraphVertex sommet_presquesouscurseur(Point point) {
         for(GraphVertex v : vertices)
        {
            if(v.almostcontains(point))
                return v;
        }
        return null;
    }
    
    void sommet_supprimer(GraphVertex v) {
        ArrayList<GraphEdge> edgestodelete = new ArrayList<GraphEdge>();
        for(GraphEdge e : edges)
        {
            if((e.getDest() == v) || (e.getSource() == v) )
            {
                edgestodelete.add(e);
            }
        }
        
        for(GraphEdge e : edgestodelete)
        {
            arc_supprimer(e);
        }
        
        vertices.remove(v);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenu1 = new javax.swing.JMenu();
        jRadioButtonMenuItemShowAllFormulas = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItemShowOnlyShortFormulas = new javax.swing.JRadioButtonMenuItem();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();

        jPopupMenu1.setName("jPopupMenu1"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(lotrecscheme.LispuApp.class).getContext().getResourceMap(GraphPanel.class);
        jMenu1.setText(resourceMap.getString("jMenu1.text")); // NOI18N
        jMenu1.setName("jMenu1"); // NOI18N

        jRadioButtonMenuItemShowAllFormulas.setSelected(true);
        jRadioButtonMenuItemShowAllFormulas.setText(resourceMap.getString("jRadioButtonMenuItemShowAllFormulas.text")); // NOI18N
        jRadioButtonMenuItemShowAllFormulas.setName("jRadioButtonMenuItemShowAllFormulas"); // NOI18N
        jRadioButtonMenuItemShowAllFormulas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItemShowAllFormulasActionPerformed(evt);
            }
        });
        jMenu1.add(jRadioButtonMenuItemShowAllFormulas);

        jRadioButtonMenuItemShowOnlyShortFormulas.setSelected(true);
        jRadioButtonMenuItemShowOnlyShortFormulas.setText(resourceMap.getString("jRadioButtonMenuItemShowOnlyShortFormulas.text")); // NOI18N
        jRadioButtonMenuItemShowOnlyShortFormulas.setName("jRadioButtonMenuItemShowOnlyShortFormulas"); // NOI18N
        jMenu1.add(jRadioButtonMenuItemShowOnlyShortFormulas);

        jPopupMenu1.add(jMenu1);

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("CheckBox");
        jCheckBoxMenuItem1.setName("jCheckBoxMenuItem1"); // NOI18N
        jPopupMenu1.add(jCheckBoxMenuItem1);

        setBackground(resourceMap.getColor("Form.background")); // NOI18N
        setFont(resourceMap.getFont("Form.font")); // NOI18N
        setName("Form"); // NOI18N
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.LINE_AXIS));
    }// </editor-fold>//GEN-END:initComponents

private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked
// TODO add your handling code here:
    if((graphVertexCurrent != null) && (evt.getClickCount() == 2) && canVerticeDialogToSeeContents)
    {
        GraphNodeDialog d = new GraphNodeDialog(null, 
                     graphVertexCurrent.getName(),
                graphVertexCurrent.getContents(), true);
        d.setVisible(true);
    }
}//GEN-LAST:event_formMouseClicked

private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
// TODO add your handling code here:
    if(canMoveVertices)
    if(graphVertexCurrent != null)
    {
        graphVertexCurrent.setPositionMiddle(evt.getPoint());
        repaint();
    }
}//GEN-LAST:event_formMouseDragged

private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
// TODO add your handling code here:
    
}//GEN-LAST:event_formMouseEntered

private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
// TODO add your handling code here:
    
}//GEN-LAST:event_formMousePressed

private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
    if(canMoveVertices)
    {
        graphVertexCurrent = sommet_interiorsouscurseur(evt.getPoint());
    
        if(graphVertexCurrent == null)
        {
            modifierSourisCurseurNormal();
        }
        else
        {
            modifierSourisCurseurMain();
        }
    }


    graphEdgeCurrent = arc_souscurseur(evt.getPoint());

    repaint();
}//GEN-LAST:event_formMouseMoved

private void jRadioButtonMenuItemShowAllFormulasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItemShowAllFormulasActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jRadioButtonMenuItemShowAllFormulasActionPerformed

  
    private GraphVertex sommet_get(String nom)
    {
        for(GraphVertex v : vertices)
        {
            if(v.getName().equals(nom))
                return v;
        }
        return null;
    }
    
    private GraphVertex sommet_ajouter(String nom)
    {
        GraphVertex newVertex = new GraphVertex(nom);
        newVertex.setPositionMiddle(pointinterieuraupif());
        vertices.add(newVertex);
        
        return newVertex;
        
    }
    
    
    
    private Point pointinterieuraupif()
    {
        return new Point((int) Math.round(32+Math.random() * (getWidth() - 64)), 
                (int) Math.round(32+Math.random() * (getHeight() - 64)));
    }
    
    
    
    public void sommet_initialVertexSet(String nom)
    {
        initialVertex = sommet_get(nom);
    }
    
    
    private boolean sommet_existetil(String nom)
    {
       return (sommet_get(nom) != null);
    }
    
    
    public void sommet_ajouter_si_existe_pas(String nom)
    {
        if(!sommet_existetil(nom))
            sommet_ajouter(nom);
    }
    
    
    private GraphEdge arc_get(String de, String a)
    {
       GraphVertex sde = sommet_get(de);
       GraphVertex sa = sommet_get(a);
       
       for(GraphEdge e  : edges)
       {
           
           if((e.getSource() == sde) && (e.getDest() == sa))
           {
               return e;
           }
       }
       return null;
    }
    
    
    public void sommet_yajouterdublabla(String nom, String blabla)
    {
        sommet_ajouter_si_existe_pas(nom);
        sommet_get(nom).blabla_add(blabla);
    }

    private void unmarkAllNodesAsNotTreated() {
        for(GraphVertex v : vertices)
        {
            v.unmark();
        }
    }
    
    
    private ArrayList<GraphVertex> vertex_successors_get(GraphVertex v)
    {
        ArrayList<GraphVertex> succ = new ArrayList<GraphVertex>();
        for(GraphEdge e : edges)
        {
            if(e.getSource() == v)
            {
                succ.add(e.getDest());
            }
        }
        return succ;
    }
    
    
    
    private int layoutarbresub(GraphVertex v, final int xleft, int y)
    {
        final int espaceminimumX = 48;
        final int espaceY = 64;

        if(v.isMarked())
            return 0;
        
        v.mark();
        
        ArrayList<GraphVertex> succ = vertex_successors_get(v);
        v.setPositionMiddle(new Point(xleft, y));
        
        if(succ.isEmpty())
        {
            
            return v.getWidth();
        }
        else
        {
            int xcurrent = xleft;
            for(GraphVertex sv : succ)
            {
                if(!sv.isMarked())
                    xcurrent += Math.max(layoutarbresub(sv,
                                                    xcurrent + sv.getHeight() / 2,
                                                    y + v.getHeight() / 2 + sv.getHeight() / 2+espaceY),
                                     sv.getWidth())
                                  + espaceminimumX;
            }
            v.setPositionMiddle(new Point((xleft + xcurrent) / 2, y));
            return xcurrent - xleft;
        }
        
    }
    
    
    public void arc_ajouter(String arc_nom, String de, String a)
    {
        GraphEdge e = arc_get(de, a);
        
        if(e == null)
        {
            sommet_ajouter_si_existe_pas(de);
            sommet_ajouter_si_existe_pas(a);
            edges.add(new GraphEdge(arc_nom, sommet_get(de), sommet_get(a)));
        }
        else
        {
            e.ajouterblabla(arc_nom);
            
        }
    }
    
    
    public void arcextra_ajouter(String arc_nom, String de, String a)
    {

        sommet_ajouter_si_existe_pas(de);
        sommet_ajouter_si_existe_pas(a);
        GraphEdge e = new GraphEdge(arc_nom, sommet_get(de), sommet_get(a));
        e.setAsNotOriented();
        edgesextra.add(e);

    }
    
    
    public void graphe_afficher(Graphics g)
    {
        int w = getWidth();
        int h = getHeight();
        
        for(GraphVertex v : vertices)
        {
            v.widthHeightCompute(g);
        }
        
        g.setColor(Color.RED);
        for(GraphEdge e : edges)
        {
            e.draw(g);
        }
        
        g.setColor(Color.BLUE);
        for(GraphEdge e : edgesextra)
        {
            e.draw(g);
        }

        if(graphEdgeCurrent != null) {
            graphEdgeCurrent.drawWhenUnderCursor(g);
        }
        
        for(GraphVertex v : vertices)
        {
            v.drawContentsNormal(g);
        }
        
        for(GraphVertex v : vertices)
        {
            v.drawContour(g);
        }
        
        
        highlights_draw(g);
        
        if(graphVertexCurrent != null) {
            graphVertexCurrent.drawWhenUnderCursor(g);
        }


        
        
    }

    public GraphVertex getGraphVertexCurrent() {
        return graphVertexCurrent;
    }




    
    static private void Graphics2Dconfigure(Graphics2D g2)
    {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
        RenderingHints.VALUE_RENDER_QUALITY);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2Dconfigure((Graphics2D) g);
        setBackground(Color.WHITE);
        g.clearRect(0, 0, getWidth(), getHeight());
  //      g.drawImage(imgBackground.getImage(), 0, 0, null);
        //g.setColor(Color.WHITE);
        //g.fillRect(0, 0, getWidth(), getHeight());
        graphe_afficher(g);
    }
    

    public Rectangle getPreferedSize()
    {
        int w = 8;
        int h = 8;
        for(GraphVertex v : vertices)
        {
            w = Math.max(w, v.getPosition().x + v.getWidth() + 32);
            h = Math.max(h, v.getPosition().y + v.getHeight() + 32);
        }
        return new Rectangle(0, 0,w, h);
    }
    
    
    
    

    private int getMaxPositionX()
    {
        int w = 0;
        for(GraphVertex v : vertices)
        {
            w = Math.max(w, v.getPosition().x + v.getWidth() / 2);
        }
        return w;
    }


    @Override
    public Dimension getPreferredSize()
    {
        Rectangle r = getPreferedSize();
        return new Dimension(r.width, r.height);
    }
    
    
    
    
    public void setPreferredSizeFixed(boolean v)
    {
      //  preferred_size_fixed = v;
    }
    
    public ArrayList<GraphVertex> getVerticesUnder(ArrayList<Point> points)
    {
        ArrayList<GraphVertex> vs = new ArrayList<GraphVertex>();
        for(Point p : points)
        {
            for(GraphVertex v : vertices)
            {
                if(v.contains(p))
                {
                    if(!vs.contains(v))
                        vs.add(v);
                }
            }
        }
        return vs;
    }
    
    
    
    public ArrayList<GraphEdge> getEdgesUnder(ArrayList<Point> points)
    {
        ArrayList<GraphEdge> vs = new ArrayList<GraphEdge>();
        for(Point p : points)
        {
            for(GraphEdge v : edges)
            {
                if(v.contains(p))
                {
                    if(!vs.contains(v))
                        vs.add(v);
                }
            }
        }
        return vs;
    }
    
    
    
    /**
     *
     * @param scheme_expression
     * @return true if the Scheme expression is a graph
     */
    static public boolean isSchemeExpressionGraph(Object scheme_expression)
    {
        if(scheme_expression == null)
            return false;
        else
            return scheme_expression.toString().startsWith("(graph (");
    }

/**
 * fill the graph with the scheme expression  scheme_code
 * @param scheme_code
 */
    public final void graphe_remplir(String scheme_code)
    {
        JScheme js = new JScheme();
        SchemePair sp = (SchemePair) js.eval("'" + scheme_code);
        graphe_remplir(sp);
    }
    
    /**
 * fill the graph with the scheme expression  scheme_code (list of terms)
 * @param sp 
 */
    public void graphe_remplir(SchemePair sp) {
        if(sp.isEmpty()) {
            return;
        }
        
        SchemePair terme = (SchemePair) sp.first();
        
        if(terme.first().toString().equals("world"))
        {
            sommet_ajouter_si_existe_pas(
            terme.second().toString()
                    );
        }
        
        
        if(terme.first().toString().equals("root"))
        {
            sommet_initialVertexSet(
            terme.second().toString()
                    );
        }
        
        
        
        
        if(terme.length() > 2)
        {
            if(terme.second().toString().equals("link"))
            {
               if(terme.length() == 3)
               {
                   arc_ajouter("", 
                                terme.first().toString()
                                , 
                                terme.third().toString()
                                        ); 
               }
               else
               {
                   arc_ajouter(terme.third().toString(), 
                                terme.first().toString()
                                        , 
                                terme.getEltNover2(7).toString()
                                        ); 
               }
            }
            
            
            if(terme.first().toString().equals("formula"))
            {
               sommet_yajouterdublabla( 
                            terme.second().toString()
                                    ,
                           terme.third().toString()
                                    ); 
            }
            
        }
        
        
        graphe_remplir((SchemePair) sp.getRest());
        
        
        
    }
    
    /**
     * delete all the graph and initialize the graph with the scheme_expression
     * @param scheme_expression
     */
    public void load(Object scheme_expression)
    {
        graphe_initialiser();
        
        JScheme js = new JScheme();
        SchemePair sp = (SchemePair) js.eval("'" + scheme_expression.toString());
        graphe_remplir((SchemePair) sp.second());
        graphLayoutCompute();
        repaint();
    }
    
    
    public String getSchemeCode()
    {
      
        return "(" + getSchemeCodeWithoutExternalBracket() + ")";
    }


    public String getSchemeCodeForConditions()
    {

        return "(" + getSchemeCodeWithoutExternalBracketForConditions() + ")";
    }
    
    public String getSchemeCodeWithoutExternalBracket()
    {
        String s = "";
        for(GraphVertex v : vertices)
        {
            for(String f : v.getFormulas())
            {
                s += "(formula " + v.getName() + " " + f + ")";
            }
        }

        for(GraphEdge e : edges)
        {
            for(String r : e.getRelationsName())
            {
                 s += "(" + e.getDepart().getName() + " link " +
                          r + " " +
                          e.getArrive().getName() + ")";
            }
        }


        for(GraphVertex v : vertices)
        {
            s += "(world " + v.getName() + ")";
        }


        return s;
    }


/**
 *
 * @return the schemeCode but without (world A) where A contains some formulas.
 */
    public String getSchemeCodeWithoutExternalBracketForConditions()
    {
        String s = "";
        for(GraphVertex v : vertices)
        {
            for(String f : v.getFormulas())
            {
                s += "(formula " + v.getName() + " " + f + ")";
            }
        }

        for(GraphEdge e : edges)
        {
            for(String r : e.getRelationsName())
            {
                 s += "(" + e.getDepart().getName() + " link " +
                          r + " " +
                          e.getArrive().getName() + ")";
            }
        }


        for(GraphVertex v : vertices)
        {
            if(v.getFormulas().isEmpty())
                 s += "(world " + v.getName() + ")";
        }


        return s;
    }
    
    private ArrayList<GraphVertex> highlights_vertices = new ArrayList<GraphVertex>();
    
    private void highlights_draw(Graphics g)
    {
        for(GraphVertex v : highlights_vertices)
        {
            v.drawWhenHighLighted(g);
        }
    }
    
    
    public void highlights_reset()
    {
        highlights_vertices = new ArrayList<GraphVertex>();
    }
    
    
    public void highlights_vertex_add(GraphVertex v)
    {
        highlights_vertices.add(v);
    }
    
    
    public void vertex_positions_inherit(GraphPanel g)
    {
        for(GraphVertex v : vertices)
        {
            GraphVertex v_in_g = g.getVertex(v.getName());
            
            if(v_in_g != null)
            {
                v.setPositionMiddle(v_in_g.getPosition());
            }
        }
    }
    
    
    public void highlights_highlight(Object scheme_expression)
            //exemple : scheme_expression = " ((world 1) (formula 1 p))"
    {
        highlights_reset();
        JScheme js = new JScheme();
        SchemePair sp = (SchemePair) js.eval("'" + scheme_expression.toString());
        highlights_highlight_rec((SchemePair) sp);
    }
    
    
    public void highlights_highlight_rec(SchemePair sp) {
        if(sp.isEmpty())
           return;
        
        SchemePair terme = (SchemePair) sp.first();
        
        if(terme.first().toString().equals("world"))
        {
            highlights_vertex_add(sommet_get(
            terme.second().toString())       );
        }
        
   
        
        if(terme.length() > 2)
        {
            if(terme.second().toString().equals("link"))
            {
//               if(terme.length() == 3)
//               {
//                   arc_ajouter("", 
//                                terme.first().toString()
//                                , 
//                                terme.third().toString()
//                                        ); 
//               }
//               else
//               {
//                   arc_ajouter(terme.third().toString(), 
//                                terme.first().toString()
//                                        , 
//                                terme.getEltNover2(7).toString()
//                                        ); 
//               }
            }
            
            
            if(terme.first().toString().equals("formula"))
            {
                sommet_get(
            terme.second().toString())
                        .highlights_highlightformula(
                        SchemeEdit.scheme_convertir_avec_des_caracteres_dessins(
                           terme.third().toString()
                                             ) );
            }
            
        }
        
        
        highlights_highlight_rec((SchemePair) sp.getRest());
        
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemShowAllFormulas;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItemShowOnlyShortFormulas;
    // End of variables declaration//GEN-END:variables

    private boolean isUpperCase(String name) {
        return name.toUpperCase().equals(name);
    }

    @Override
    public void doLayout() {
        super.doLayout();
        recalc();
    }

    private boolean allNodesTreated() {
        for(GraphVertex v : vertices)
        {
            if(!v.isMarked())
                return false;
        }
        return true;
    }

    private GraphVertex getNodeNextRoot() {
       for(GraphVertex v : vertices)
        {
            if(!v.isMarked())
                return v;
        }
        return null;
    }



    static public Icon getIcon(String schemeSetOfTerms)
    {
        GraphPanel gp = new GraphPanel(schemeSetOfTerms);
        gp.setSize(256, 128);
        gp.graphLayoutCompute();
        gp.repaint();
        int width = gp.getWidth();
        int height = gp.getHeight();
        BufferedImage image = new BufferedImage(width, height, 
                                                  BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        
        Graphics2Dconfigure(g);
        g.setColor(Color.WHITE);
        g.clearRect(0, 0, width, height);
        
        
        gp.graphe_afficher(g);
        g.dispose();
        return new ImageIcon(image);

    }

}
