/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lotrecscheme;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.util.ArrayList;

/**
 *
 * @author proprietaire
 */
public class PenSketch {
    private ArrayList<Point> points = null;

    public ArrayList<Point> getPoints() {
        return points;
    }

    boolean isPoint() {
        return points.size() < 20;
    }
    
       
    
    PenSketch() 
        {
            points = new ArrayList<Point>();
        }
    
    
    void styloPointAjouter(Point point)
    {
        points.add(point);
    }
    
    
   
    
    
    
    private double getAngleAuPoint(int i)
    {
        return Math.atan2(points.get(i+1).y - points.get(i).y,
                          points.get(i+1).x - points.get(i).x);
    }
    
    
    
        
    private double getAngleEntreExtremiteLaPlusLoinEtPoint(int i)
    {
        if(i < points.size() / 2)
        {
            int ifin = points.size() - 1;
            return Math.atan2(points.get(ifin).y - points.get(i).y,
                              points.get(ifin).x - points.get(i).x);
        }
        else
        {
            return Math.atan2(points.get(i).y - points.get(0).y,
                          points.get(i).x - points.get(0).x);
        }
        
    }
    
    
    private double getSegmentAngleMoyen()
    {
        double sommeangle = 0;
        for(int i = 0; i < points.size() - 2; i++)
        {
            sommeangle += getAngleAuPoint(i);
        }
        
        return sommeangle / (points.size() - 1);
    }
    
    public boolean isSegment()
    {

        if(points.size() < 2)
            return false;
        
        double anglemoyen = getSegmentAngleMoyen();
        
        if(points.size() > 10)
            anglemoyen += 0;
        
        
        
        for(int i = 0; i < points.size() - 2; i++)
        {
            if(Math.abs(getAngleEntreExtremiteLaPlusLoinEtPoint(i) - anglemoyen) > 0.5)
                return false;
        }
        
        
        return true;
    }
    
    
    
    
    private float calcA(Point P, Point Q)
    {
        if(P.x == Q.x)
             return 1;
        else
            return -(P.y - Q.y) / (P.x - Q.x);
    }
    
    
    private float calcB(Point P, Point Q)
    {
        if(P.x == Q.x)
             return 0;
        else
            return 1;
    }
    
    
    
    private float calcC(Point P, Point Q)
    {
        if(P.x == Q.x)
             return -P.x;
        else
            return -(calcA(P, Q)*P.x + calcB(P, Q)*P.y);
        
        
    }
    
    
    
    
    private Point isIntersection(Point A, Point B, Point C, Point D)
    //renvoie le point d'intersection si les segments [AB] et [CD] s'intersectent
    //sinon renvoie null        
    {
        float a1 = calcA(A, B);
        float b1 = calcB(A, B);
        float c1 = calcC(A, B);
        
        float a2 = calcA(C, D);
        float b2 = calcB(C, D);
        float c2 = calcC(C, D);
        
        float delta = a1*b2 - a2*b1;
        
        
        if(delta == 0)
            return null;
        else
        {
            Point I = new Point((int) ((b2*c1 - b1*c2) / delta),
                    (int)((- a2*c1 + a1*c2)/ delta));
            
            if(((a1*C.x + b1*C.y + c1) * (a1*D.x + b1*D.y + c1) <= 0) &&
             ((a2*A.x + b2*A.y + c2) * (a2*B.x + b2*B.y + c2) <= 0))
                return I;
            else
                return null;
                       
        }

    }




    
    public ArrayList<Point> getPointsWhereWeErase()
    {
        ArrayList<Point> pts = new ArrayList<Point>();
        for(int i = 0; i < points.size() - 2; i++)
        {
            for(int j = 0; j < points.size() - 2; j++)
                if(Math.abs(j-i) > 2)
                {
                    if(isIntersection(points.get(i),
                                      points.get(i+1),
                                      points.get(j),
                                      points.get(j+1)) != null)
                        pts.add(points.get(i));
                }
                
        }
        return pts;
    }
    
    
    private boolean isIntersectionInPoints()
    {
        for(int i = 0; i < points.size() - 2; i++)
        {
            for(int j = 0; j < points.size() - 2; j++)
                if(Math.abs(j-i) > 2)
                {
                    if(isIntersection(points.get(i),
                                      points.get(i+1),
                                      points.get(j),
                                      points.get(j+1)) != null)
                        return true;
                }
                
        }
        
        return false;
        
    }
    
    
    
    public boolean isGribouilli()
    {
        if(isSegment())
            return false;
        else
        return (points.size() > 10) && (isIntersectionInPoints());
    }
    
    
    public boolean isPolygon()
    {
        return ( (points.size() > 10) && !isSegment() && !isIntersectionInPoints());
    }
    
    
    
    public Polygon getPolygon()
    {
        Polygon p = new Polygon();
        for(int i = 0; i < points.size() - 1; i++)
        {
            p.addPoint(points.get(i).x,
                       points.get(i).y);
        }
        
        return p;
    }
    
    
    void afficher(Graphics2D g)
    {
        if(points.size() == 0)
            return;
        
        Point pa = points.get(0);
        
        
        if(isGribouilli())
        {
            g.setStroke(new BasicStroke(4));
            g.setColor(Color.white);
        }
        else if(isPoint())
        {
            g.setColor(Color.gray);
        }
        else
            g.setColor(Color.red);

        
        for(Point p : points)
        {
            g.drawLine(pa.x, pa.y, p.x, p.y);
            pa = p;
        }
    }
    
    
}
