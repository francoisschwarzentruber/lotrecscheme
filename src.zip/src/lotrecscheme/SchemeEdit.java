package lotrecscheme;

import java.awt.Color;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;

/*
 * SchemeEdit.java
 *
 * Created on 22 août 2008, 01:19
 */
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import jscheme.JScheme;



/**
 *
 * @author  François Schwarzentruber
 */
public class SchemeEdit extends javax.swing.JPanel {

    static String scheme_convertir_entextebrut(String texte) {
        return texte.replace("◊ ", "diamond ")
                    .replace("□ ", "box ")
                    .replace("¬ ", "not ")
                    .replace(" ٨ ", " and ")
                    .replace(" ٧ ", " or ")
        .replace(" → ", " imply ")
        .replace(" ↔ ", " equiv ")
        .replace(" ⊤ ", " top ")
        .replace(" ⊥ ", " bottom ");
    }
    
    public static String scheme_convertir_avec_des_caracteres_dessins(String texte)
    {
       // if(texte.equals("top"))
       //     return "⊤";
        
       // if(texte.equals("bottom"))
       //     return "⊥";
        
        if(texte.length() < 100 )
             return texte.replace("diamond ", "◊ ")
                    .replace("box ", "□ ")
                    .replace("not ", "¬ ")
                    .replace(" and ", " ٨ ")
                    .replace(" or ", " ٧ ");
                    //.replace("imply ", "→ ")
                    //.replace("equiv ", "↔ ")
                  //  .replace("top ", "⊤ ")
                  //  .replace(" bottom ", " ⊥ ");
        else
            return texte;
    }
    
    

    private boolean isQueTexteBrut = false;
    
    String obtenir_texte_brut(String texte)
    {
        if(isQueTexteBrut)
            return texte;
        else
         return scheme_convertir_entextebrut(texte);
        
    }
    
    
    void texteBrutSet(boolean queTexteBrut)
    {
        isQueTexteBrut = queTexteBrut;
    }
    
    
    
    void remplacements_symboles()
    {
        if(isQueTexteBrut)
            return;
        
        String texte = jTextPane.getText();
        
        boolean modifie = false;
        int cur = jTextPane.getCaretPosition();
                
        String nouveautexte = texte.replace("diamond ", "◊ ");
        if(nouveautexte.length() != texte.length())
        {
            cur += nouveautexte.length() - texte.length();
            modifie = true;
        }
        
        texte = nouveautexte;
        nouveautexte = texte.replace("box ", "□ ");
        if(nouveautexte.length() != texte.length())
        {
            cur += nouveautexte.length()-texte.length();
            modifie = true;
        }
        
        texte = nouveautexte;
        nouveautexte = texte.replace("not ", "¬ ");
        if(nouveautexte.length() != texte.length())
        {
            cur += nouveautexte.length()-texte.length();
            modifie = true;
        }
        
        texte = nouveautexte;
        nouveautexte = texte.replace(" and ", " ٨ ");
        if(nouveautexte.length() != texte.length())
        {
            cur += nouveautexte.length()-texte.length();
            modifie = true;
        }
        
        texte = nouveautexte;
        nouveautexte = texte.replace(" or ", " ٧ ");
        if(nouveautexte.length() != texte.length())
        {
            cur += nouveautexte.length()-texte.length();
            modifie = true;
        }
        
        if(modifie)
        {
            jTextPane.setText(nouveautexte);
            if(cur < 0)
                cur = 0;

            jTextPane.setCaretPosition(cur);
        }
        
    }
    
    private void declencherEvenementChanged() {
        remplacements_symboles();
        

        
        
    }

    
    public ArrayList<String> getLines()
    {
        String s = jTextPane.getText(); 
        JTextArea TA = new JTextArea(s)  ;
        ArrayList<String> ss = new ArrayList<String>();
        
        for(int i = 0; i < TA.getLineCount() ;i++)
        {
            try {
                int start = TA.getLineStartOffset(i);
                int fin = TA.getLineEndOffset(i);
                String item = s.substring(start, fin);
                
                item = item.trim();
                
                if(!item.equals(""))
                    ss.add(item);
            } catch (BadLocationException ex) {
                Logger.getLogger(GraphEditorGraphVertexEditorDialog.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        return ss;
    }
    
    


    public boolean isOK() {
        return isSchemeSyntaxOK(getText());
    }

    private static boolean isSchemeSyntaxOK(String text) {
        int count = 0;
        for(int i = 0 ; i < text.length(); i++)
        {
            if(text.charAt(i) == '(')
                count++;

            if(text.charAt(i) == ')')
                count--;

            if(count < 0)
                return false;
        }

        return (count == 0);

//        JScheme js = new JScheme();
//        try
//        {
//            js.eval("'(" + text + ")");
//        }
//        catch(Exception e)
//        {
//            return false;
//        }
//
//        return true;
    }
    
    public class ColorationSyntaxique implements Runnable {
      /** Edition flag.
       */ 
      boolean isColoring = false;       

      /** @inheritDoc
       */

      /** Color the document later at Event Dispatch.
       * <br>Does nothing if current edition event is related to coloring modifications within the document.
       */
      private void  doColoringLater() {
        if (!isColoring) {
          SwingUtilities.invokeLater(this);
        }
      }

      /** @inheritDoc
       */
      public void run() { 
        isColoring = true;
        try {
          coloration();
        }
        finally { 
          isColoring = false;
        }
      }
    } 

    private ColorationSyntaxique colorationSyntaxique = null;
    /** Creates new form SchemeEdit */
    public SchemeEdit() {
        initComponents();
        
        colorationSyntaxique = new ColorationSyntaxique();
    }
    
    
    
    public void setText(String text)
    {
        jTextPane.setText(text);
        declencherEvenementChanged();
        
        coloration(); 
        
    }
    
    
    public String getText()
    {
        return obtenir_texte_brut(jTextPane.getText());
    }
    

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane = new javax.swing.JTextPane();

        setName("Form"); // NOI18N
        setLayout(new java.awt.BorderLayout());

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(lotrecscheme.LispuApp.class).getContext().getResourceMap(SchemeEdit.class);
        jTextPane.setContentType(resourceMap.getString("jTextPane.contentType")); // NOI18N
        jTextPane.setFont(resourceMap.getFont("jTextPane.font")); // NOI18N
        jTextPane.setName("jTextPane"); // NOI18N
        jTextPane.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTextPaneCaretUpdate(evt);
            }
        });
        jTextPane.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextPaneKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTextPane);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    
private char getCharWithIndice(String texte, int i)    
{
    if(i < 0)
        i = 0;
    
    if(i >= texte.length())
        i = texte.length() - 1;
    
     return texte.charAt(i);   
}





private int getIndiceParentheseOuvranteContexteCourant()
{
    int profondeur = 0;
    
    String texte = jTextPane.getText();
    int i = jTextPane.getSelectionStart();
    
    
    
    // .... )|..., on ne compte pas la parenthèse...
    if (getCharWithIndice(texte, i-1) == ')')
        i--;
     
    if(i == texte.length())
        i = texte.length() - 1;
    
    // .... |)..., on ne compte pas la parenthèse...
    if(getCharWithIndice(texte, i) == ')')
        i--;
    
    
    // .... |(....//
    if(getCharWithIndice(texte, i) == '(')
        return i;
    
        
        
    for(; i >= 0; i--)
    {
        if(getCharWithIndice(texte, i) == '(')
        {
            if(profondeur == 0)
               return i;
            else
                profondeur--;
        }
        else if(getCharWithIndice(texte, i) == ')')
        {  
            profondeur++;   
            
        }
    }
    return -1;
            
}


private int getIndiceParentheseFermanteContexteCourant()
{
    int profondeur = 0;
    
    String texte = jTextPane.getText();
    int i = jTextPane.getSelectionStart();
    
    // .... )|....//
    if(getCharWithIndice(texte, i-1) == ')')
        return i;
    
    // ......x| où x n'est pas une parenthèse
    if(i == texte.length())
        return texte.length()+1;

    
    // .... |(..., on ne compte pas la parenthèse...
    if (getCharWithIndice(texte, i) == '(')
        i++;
        
    
    
    // .... |)....//
    if(getCharWithIndice(texte, i) == ')')
        return i+1;
    
    

    for(; i < texte.length(); i++)
    {
        if(getCharWithIndice(texte, i) == ')')
        {
            if(profondeur == 0)
               return i+1;
            else
                profondeur--;
        }
        else if(getCharWithIndice(texte, i) == '(')
        {  
            profondeur++;   
            
        }
    }
    return jTextPane.getText().length()+1;
            
}









private void coloration_toutnormal()
{
    StyledDocument doc = jTextPane.getStyledDocument();
    jTextPane.addStyle("normal", null);
    String texte = jTextPane.getText();
    doc.setCharacterAttributes(0, texte.length(), jTextPane.getStyle("normal"), true);
}






private void coloration()
{
    if(isOK())
    {
        jTextPane.setBackground(Color.WHITE);
    }
    else
    {
        jTextPane.setBackground(new Color(1.0f, 0.8f, 0.8f));
    }


    coloration_toutnormal();
    coloration_boitecourante();
    

    
}




void coloration_boitecourante()
{
    if(jTextPane.getText().length() == 0)
        return;
    
    Style styleboite = jTextPane.addStyle("boite", null);
    StyleConstants.setBackground(styleboite, new Color(245, 245, 96));
    StyleConstants.setForeground(styleboite, Color.blue);
    //StyleConstants.setFontSize(styleboite, 16);
    StyleConstants.setBold(styleboite, true);
    
    Style styleboiteerror = jTextPane.addStyle("boiteerror", null);
    StyleConstants.setBackground(styleboiteerror, new Color(245, 245, 96));
    StyleConstants.setForeground(styleboiteerror, Color.red);
    //StyleConstants.setFontSize(styleboite, 16);
    StyleConstants.setBold(styleboiteerror, true);
    
    
    StyledDocument doc = jTextPane.getStyledDocument();
    
    int boitedebut = getIndiceParentheseOuvranteContexteCourant();
    int boitefin = getIndiceParentheseFermanteContexteCourant();
    
    if((0 <= boitedebut) && (boitefin <= jTextPane.getText().length()))
    {
        doc.setCharacterAttributes(boitedebut,
                                   1,
                jTextPane.getStyle("boite"), false);

        doc.setCharacterAttributes(boitefin-1,
                                   1,
                jTextPane.getStyle("boite"), false);
    }
    else if((0 <= boitedebut))
    {
        doc.setCharacterAttributes(boitedebut,
                                   1,
                jTextPane.getStyle("boiteerror"), false);
        
    }
    else if((boitefin <= jTextPane.getText().length()))
    {
        doc.setCharacterAttributes(boitefin-1,
                                   1,
                jTextPane.getStyle("boiteerror"), false);
        
    }
    

}
    
    
private void jTextPaneCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTextPaneCaretUpdate
// TODO add your handling code here:
    try
    {
       colorationSyntaxique.doColoringLater();
    }
    catch (java.lang.IllegalStateException e)
    {
        
    }
    
    
}//GEN-LAST:event_jTextPaneCaretUpdate

private void jTextPaneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextPaneKeyPressed
// TODO add your handling code here:
    declencherEvenementChanged();
    try
    {
       colorationSyntaxique.doColoringLater();
    }
    catch (java.lang.IllegalStateException e)
    {
        
    }
}//GEN-LAST:event_jTextPaneKeyPressed



 public void insertText(String txt)
 {
     jTextPane.replaceSelection(txt);
     
 }
 
 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane;
    // End of variables declaration//GEN-END:variables

}
