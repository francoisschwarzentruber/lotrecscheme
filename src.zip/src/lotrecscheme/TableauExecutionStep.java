/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lotrecscheme;

/**
 *
 * @author Ancmin
 */
public class TableauExecutionStep {
    final private String premodel;
    final private String nextRule;
    final private String sigma;

    public TableauExecutionStep(String premodel, String nextRule, String sigma) {
        this.premodel = premodel;
        this.nextRule = nextRule;
        this.sigma = sigma;
    }

    public String getNextRule() {
        return nextRule;
    }

    public String getPremodel() {
        return premodel;
    }
    
    public String getSigma() {
        return sigma;
    }
}
